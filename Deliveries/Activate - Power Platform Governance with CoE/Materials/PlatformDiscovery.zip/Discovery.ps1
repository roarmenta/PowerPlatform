﻿param
(
    [Parameter(Mandatory=$false)]
    [ValidateSet("usgov", "usgovhigh", "dod")]
    [string]
    $GCC
)


# Provide credentials of user account having Power Platform Admin or Global Admin role
$creds = Get-Credential




if (![string]::IsNullOrEmpty($GCC))
{
    Add-PowerAppsAccount -Endpoint $gcc -Username $creds.UserName -Password $creds.GetNetworkCredential().SecurePassword
}
else
{
    Add-PowerAppsAccount -Endpoint prod -Username $creds.UserName -Password $creds.GetNetworkCredential().SecurePassword
}



# file paths
$EnvironmentFilePath = "$PSScriptRoot\Output\Environments.csv"
$AppFilePath = "$PSScriptRoot\Output\Apps.csv"
$AppConnectionsFilePath = "$PSScriptRoot\Output\AppConnections.csv"
$AppRoleAssignmentsFilePath = "$PSScriptRoot\Output\AppPermissions.csv"
$FlowFilePath = "$PSScriptRoot\Output\Flows.csv"
$FlowConnectionsFilePath = "$PSScriptRoot\Output\FlowConnections.csv"
$FlowRoleAssignmentsFilePath = "$PSScriptRoot\Output\FlowPermissions.csv"


New-Item -ItemType Directory -Path "$PSScriptRoot\Output" -Force | Out-Null


# Add the header to the environments csv file
$envFileHeaders = "EnvironmentName," `
        + "EnvironmentType," `
        + "Region," `
        + "CreatedBy," `
        + "CreatedTime," `
        + "LastModifiedBy," `
        + "LastModifiedTime"
     

$i = Get-ChildItem -Path $EnvironmentFilePath -ErrorAction Ignore

if ($i -ne $null)
{
    Remove-Item -Path $EnvironmentFilePath 
}
  
Add-Content -Path $EnvironmentFilePath -Value $envFileHeaders




# Add the header to the app csv file
$appFileHeaders = "EnvironmentName," `
        + "AppName," `
        + "CreatedTime," `
        + "LastModifiedTime," `
        + "AppDisplayName," `
        + "AppOwnerObjectId," `
        + "AppOwnerDisplayName," `
        + "AppOwnerDisplayEmail," `
        + "AppOwnerUserPrincipalName," `
        + "AppConnections";



$i = Get-ChildItem -Path $AppFilePath -ErrorAction Ignore

if ($i -ne $null)
{
    Remove-Item -Path $AppFilePath
}

Add-Content -Path $AppFilePath -Value $appFileHeaders




# Add the header to the App connections csv file
$appConnectionsHeaders = "EnvironmentName," `
        + "AppName," `
        + "ConnectorName," `
        + "Tier," `
        + "AppConsent," `
        + "IsOnPrem,";

$i = Get-ChildItem -Path $AppConnectionsFilePath -ErrorAction Ignore

if ($i -ne $null)
{
    Remove-Item -Path $AppConnectionsFilePath
}

Add-Content -Path $AppConnectionsFilePath -Value $appConnectionsHeaders






<# Add the header to the app roles csv file
$appRoleAssignmentsHeaders = "EnvironmentName," `
        + "AppName," `
        + "CreatedTime," `
        + "LastModifiedTime," `
        + "AppDisplayName," `
        + "AppOwnerObjectId," `
        + "AppOwnerDisplayName," `
        + "AppOwnerDisplayEmail," `
        + "AppOwnerUserPrincipalName," `
        + "AppConnections," `
        + "RoleType," `
        + "RolePrincipalType," `
        + "RolePrincipalObjectId," `
        + "RolePrincipalDisplayName," `
        + "RolePrincipalEmail," `
        + "RoleUserPrincipalName,";


$i = Get-ChildItem -Path $AppRoleAssignmentsFilePath -ErrorAction Ignore

if ($i -ne $null)
{
    Remove-Item -Path $AppRoleAssignmentsFilePath
}

Add-Content -Path $AppRoleAssignmentsFilePath -Value $appRoleAssignmentsHeaders
#>



# Add the header to the flow  csv file
$flowFileHeaders = "EnvironmentName," `
        + "FlowName," `
        + "CreatedTime," `
        + "LastModifiedTime," `
        + "FlowDisplayName," `
        + "FlowOwnerObjectId," `
        + "FlowOwnerDisplayName," `
        + "FlowOwnerDisplayEmail," `
        + "FlowOwnerUserPrincipalName," `
        + "FlowConnections," `
        + "FlowConnectors";


$i = Get-ChildItem -Path $FlowFilePath -ErrorAction Ignore

if ($i -ne $null)
{
    Remove-Item -Path $FlowFilePath
}

Add-Content -Path $FlowFilePath -Value $flowFileHeaders




# Add the header to the Flow connections csv file
$flowConnectionsHeaders = "EnvironmentName," `
        + "FlowName," `
        + "ConnectorName," `
        + "ConnectionName," `
        + "ConnectionId," `
        + "Tier," `
        + "Status," `
        + "Created," `
        + "Modified," `
        + "Owner";

$i = Get-ChildItem -Path $FlowConnectionsFilePath -ErrorAction Ignore

if ($i -ne $null)
{
    Remove-Item -Path $FlowConnectionsFilePath
}

Add-Content -Path $FlowConnectionsFilePath -Value $flowConnectionsHeaders




<# Add the header to the app roles csv file
$flowRoleAssignmentsHeaders = "EnvironmentName," `
        + "FlowName," `
        + "CreatedTime," `
        + "LastModifiedTime," `
        + "FlowDisplayName," `
        + "FlowOwnerObjectId," `
        + "FlowOwnerDisplayName," `
        + "FlowOwnerDisplayEmail," `
        + "FlowOwnerUserPrincipalName," `
        + "FlowConnectionOwner," `
        + "FlowConnections," `
        + "FlowConnectionPlusOwner," `
        + "RoleType," `
        + "RolePrincipalType," `
        + "RolePrincipalObjectId," `
        + "RolePrincipalDisplayName," `
        + "RolePrincipalEmail," `
        + "RoleUserPrincipalName,";


$i = Get-ChildItem -Path $FlowRoleAssignmentsFilePath -ErrorAction Ignore

if ($i -ne $null)
{
    Remove-Item -Path $FlowRoleAssignmentsFilePath
}

Add-Content -Path $FlowRoleAssignmentsFilePath -Value $flowRoleAssignmentsHeaders
#>



# GET ALL CONNECTIONS FROM THE TENANT
$connections = Get-AdminPowerAppConnection



$envs = Get-AdminPowerAppEnvironment -ApiVersion "2020-09-01"

Write-Host "Discovering Environments..."

foreach($env in $envs)
{
    #Get the details around who created the app
    $EnvironmentName = $env.DisplayName
    $EnvironmentType = $env.EnvironmentType
    $Region = $env.Location
    $CreatedBy = $env.CreatedBy.Email
    $CreatedTime = $env.CreatedTime
    $LastModifiedBy = $env.LastModifiedBy
    $LastModifiedTime = $env.LastModifiedTime
   

    # First write the app record along with who created it and the connections of the app
    $row = $EnvironmentName + "," `
        + $EnvironmentType + "," `
        + $Region + "," `
        + $CreatedBy + "," `
        + $CreatedTime + "," `
        + $LastModifiedBy + "," `
        + $LastModifiedTime;
        
    Add-Content -Path $EnvironmentFilePath -Value $row 

    Write-Host " - $EnvironmentName"

}

Write-Host


#populate the app files
$apps = Get-AdminPowerApp

write-host "Discovering Power Apps (Canvas)..."

foreach($app in $apps)
{
    #Get the details around who created the app
    $AppEnvironmentName = $app.EnvironmentName
    $Name = $app.AppName
    $DisplayName = $app.displayName -replace '[,]'
    $OwnerObjectId = $app.owner.id
    $OwnerDisplayName = $app.owner.displayName -replace '[,]'
    $OwnerDisplayEmail = $app.owner.email
    $CreatedTime = $app.CreatedTime
    $LastModifiedTime = $app.LastModifiedTime


    # First write the app record along with who created it and the connections of the app
    $row = $AppEnvironmentName + "," `
        + $Name + "," `
        + $CreatedTime + "," `
        + $LastModifiedTime + "," `
        + $DisplayName + "," `
        + $OwnerObjectId + "," `
        + $OwnerDisplayName + "," `
        + $OwnerDisplayEmail + "," `
        + $OwnerUserPrincipalName;

    Add-Content -Path $AppFilePath -Value $row 

    $userOrGroupObject = Get-UsersOrGroupsFromGraph -ObjectId $OwnerObjectId
    $OwnerUserPrincipalName = $userOrGroupObject.UserPrincipalName

    #Get the list of connections for the app
    $connectionList = ""

    foreach($conRef in $app.Internal.properties.connectionReferences)
    {
        foreach($connection in $conRef)
        {
            foreach ($connId in ($connection | Get-Member -MemberType NoteProperty).Name) 
            {
                $connDetails = $($connection.$connId)

                $connDisplayName = $connDetails.displayName -replace '[,]'
                $connIconUri = $connDetails.iconUri
                $apiTier = $connDetails.apiTier
                $bypassConsent = $connDetails.bypassConsent
                $isOnPremiseConnection = $connDetails.isOnPremiseConnection
                $connId = $connDetails.id

                
                # First write the app record along with who created it and the connections of the app
                $row = $AppEnvironmentName + "," `
                    + $Name + "," `
                    + $connDisplayName + "," `
                    + $apiTier + "," `
                    + $bypassConsent + "," `
                    + $isOnPremiseConnection;

                Add-Content -Path $AppConnectionsFilePath -Value $row 

            }
        }        
    }

    
    <#Get all of the details for each user the app is shared with
    $principalList = ""
    foreach($appRole in ($app | Get-AdminPowerAppRoleAssignment))
    {
        $RoleEnvironmentName = $appRole.EnvironmentName
        $RoleType = $appRole.RoleType
        $RolePrincipalType = $appRole.PrincipalType
        $RolePrincipalObjectId = $appRole.PrincipalObjectId
        $RolePrincipalDisplayName = $appRole.PrincipalDisplayName -replace '[,]'
        $RolePrincipalEmail = $appRole.PrincipalEmail
        $CreatedTime = $app.CreatedTime
        $LastModifiedTime = $app.LastModifiedTime

        If($appRole.PrincipalType -eq "Tenant")
        {
            $RolePrincipalDisplayName = "Tenant"
            $RoleUserPrincipalName = ""
        }
        If($appRole.PrincipalType -eq "User")
        {
            $userOrGroupObject = Get-UsersOrGroupsFromGraph -ObjectId $appRole.PrincipalObjectId 
            $RoleUserPrincipalName = $userOrGroupObject.UserPrincipalName  
            
        }

        # Write this permission record 
        $row = $AppEnvironmentName + "," `
                + $Name + "," `
                + $CreatedTime + "," `
                + $LastModifiedTime + "," `
                + $DisplayName + "," `
                + $OwnerObjectId + "," `
                + $OwnerDisplayName + "," `
                + $OwnerDisplayEmail + "," `
                + $OwnerUserPrincipalName + "," `
                + $RoleType + "," `
                + $RolePrincipalType + "," `
                + $RolePrincipalObjectId + "," `
                + $RolePrincipalDisplayName + "," `
                + $RolePrincipalEmail + "," `
                + $RoleUserPrincipalName;
        Add-Content -Path $AppRoleAssignmentsFilePath -Value $row 
    }
    #>

    Write-Host " - $($DisplayName)"
}


Write-Host

$flows = Get-AdminFlow

Write-Host "Discovering Flows..."

foreach($flow in $flows)
{
    if ($flow.FlowName -ne $null)
    {
        $env = $envs | ? { $_.EnvironmentName -eq $flow.EnvironmentName } 

        $FlowEnvironmentName = $env.EnvironmentName
        $FlowName = $flow.FlowName
        $DisplayName = $flow.displayName -replace '[,]'
        $OwnerObjectId = $flow.createdBy.objectid
        $OwnerDisplayName = $flow.createdBy.displayName -replace '[,]'
        $OwnerDisplayEmail = $flow.createdBy.email
        $CreatedTime = $flow.CreatedTime
        $LastModifiedTime = $flow.LastModifiedTime

        $userOrGroupObject = Get-UsersOrGroupsFromGraph -ObjectId $OwnerObjectId
        $OwnerUserPrincipalName = $userOrGroupObject.UserPrincipalName
    
        
        $flowDetails = $flow | Get-AdminFlow

  
        $connectionList = ""
        $connectorList = ""
        
        foreach($conRef in $flowDetails.Internal.properties.connectionReferences)
        {
            foreach($connection in $conRef)
            {
                foreach ($connId in ($connection | Get-Member -MemberType NoteProperty).Name) 
                {
                    $connDetails = $($connection.$connId)
                   
                    $connectionDisplayName = $connDetails.displayName -replace '[,]'
                    $apiTier = $connDetails.tier
                    $connName = $connDetails.connectionName


                    $pattern = [System.Management.Automation.WildcardPattern]::new($connName)

                    #$pattern = BuildFilterPattern -Filter   
                                          
                    foreach ($envConnection in $connections)
                    {
                        if ($pattern.IsMatch($envConnection.ConnectionName))
                        {
                            $connectionObject = $envConnection
                            break;
                        }
                    }

                    $connectorName = $connectionObject.ConnectorName
                    $connectionName = $connectionObject.ConnectionName
                    $status = $connectionObject.Statuses.status
                    $created = $connectionObject.CreatedTime
                    $modified = $connectionObject.LastModifiedTime
                    $connectionOwner = $connectionObject.CreatedBy.UserPrincipalName

                                           
                
                    # First write the app record along with who created it and the connections of the app
                    $row = $FlowEnvironmentName + "," `
                        + $FlowName + "," `
                        + $connectorName + "," `
                        + $connectionDisplayName + "," `
                        + $connectionName + "," `
                        + $apiTier + "," `
                        + $status + "," `
                        + $created + "," `
                        + $modified + "," `
                        + $connectionOwner;

                    Add-Content -Path $FlowConnectionsFilePath -Value $row 
                    
                }
            }        
        }
        
    
        # First write the flow record along with who created it and the connections of the flow
        $row = $FlowEnvironmentName + "," `
            + $Name + "," `
            + $CreatedTime + "," `
            + $LastModifiedTime + "," `
            + $DisplayName + "," `
            + $OwnerObjectId + "," `
            + $OwnerDisplayName + "," `
            + $OwnerDisplayEmail + "," `
            + $OwnerUserPrincipalName + "," `
            + $connectionList;`
            #+ $connectionPlusConnectorList;
        Add-Content -Path $FlowFilePath -Value $row 

        <#
        $principalList = ""
        foreach($flowRole in ($flow | Get-AdminFlowOwnerRole))
        {        
            $RoleEnvironmentName = $flowRole.EnvironmentName
            $RoleType = $flowRole.RoleType
            $RolePrincipalType = $flowRole.PrincipalType
            $RolePrincipalObjectId = $flowRole.PrincipalObjectId
            $RolePrincipalDisplayName = $flowRole.PrincipalDisplayName -replace '[,]'
            $RolePrincipalEmail = $flowRole.PrincipalEmail

            If($flowRole.PrincipalType -eq "Tenant")
            {
                $RolePrincipalDisplayName = "Tenant"
                $RoleUserPrincipalName = ""
            }
            If($flowRole.PrincipalType -eq "User")
            {
                $userOrGroupObject = Get-UsersOrGroupsFromGraph -ObjectId $flowRole.PrincipalObjectId 
                $RoleUserPrincipalName = $userOrGroupObject.UserPrincipalName  
            
            }

            # Write this permission record 
            $row = $RoleEnvironmentName + "," `
                + $Name + "," `
                + $CreatedTime + "," `
                + $LastModifiedTime + "," `
                + $DisplayName + "," `
                + $OwnerObjectId + "," `
                + $OwnerDisplayName + "," `
                + $OwnerDisplayEmail + "," `
                + $OwnerUserPrincipalName + "," `
                + $RoleType + "," `
                + $RolePrincipalType + "," `
                + $RolePrincipalObjectId + "," `
                + $RolePrincipalDisplayName + "," `
                + $RolePrincipalEmail + "," `
                + $RoleUserPrincipalName;
            Add-Content -Path $FlowRoleAssignmentsFilePath -Value $row 
        }
        #>
        Write-Host " - $($DisplayName)"
        
    }
}
