﻿
$mod = Get-InstalledModule DataGateway -ErrorAction Ignore

if ($mod -eq $null)
{
    Install-Module DataGateway -Force
}

Import-Module DataGateway

Connect-DataGatewayServiceAccount | Out-Null

New-Item -ItemType Directory -Path "$PSScriptRoot\Output" -Force | Out-Null

# file paths
$GatewayFilePath = "$PSScriptRoot\Output\Gateways.csv"

# Add the header to the environments csv file
$gwFileHeaders = "ClusterName," `
        + "ClusterType," `
        + "Version," `
        + "VersionStatus," `
        + "Status," `
        + "Region," `
        + "Contact," `
        + "Machine"
     

$i = Get-ChildItem -Path $GatewayFilePath -ErrorAction Ignore

if ($i -ne $null)
{
    Remove-Item -Path $GatewayFilePath 
}
  
Add-Content -Path $GatewayFilePath -Value $gwFileHeaders

write-host

$gws = Get-DataGatewayCluster -Scope Organization

Write-Host "Discovering On-Premise Data Gateways..."

$gws | % { 
        
    $clusterName = $_.Name
    $clusterType = $_.Type
    
    $_.MemberGateways | % { 
        
        $version = $_.Version; 
        $versionStatus = $_.VersionStatus;
        $status = $_.Status;
        $state = $_.State;
        $region = $_.Region;

        $annotation = ConvertFrom-Json $_.Annotation

        $gatewayContactInformation = $annotation.gatewayContactInformation;
        $gatewayMachine = $annotation.gatewayMachine;


        # First write the app record along with who created it and the connections of the app
        $row = $clusterName + "," `
            + $clusterType + "," `
            + $version + "," `
            + $versionStatus + "," `
            + $state + "," `
            + $region + "," `
            + $gatewayContactInformation + "," `
            + $gatewayMachine;
        
        Add-Content -Path $GatewayFilePath -Value $row 
    } 

    Write-Host " - $($clusterName) ($($clusterType))"
}

write-host

Write-Host "On-premise Gateway report has been saved to: $($PSScriptRoot)\Output\Gateways.csv"